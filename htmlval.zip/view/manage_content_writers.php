<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Content Writers</title>
        <script src="../script.js"></script>
</head>
<body>
    <h1>Manage Content Writers</h1>
    
    <?php if (isset($_GET['message'])): ?>
        <p style="color: green;"><?php echo $_GET['message']; ?></p>
    <?php endif; ?>

    <form action="index.php?action=manage_content_writers" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <button type="submit">Add Content Writer</button>
    </form>

    <h2>Current Content Writers</h2>
    <?php if (!empty($contentWriters)): ?>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php foreach ($contentWriters as $writer): ?>
            <tr>
                <td><?php echo $writer['username']; ?></td>
                <td><?php echo $writer['email']; ?></td>
                <td><a href="index.php?action=manage_content_writers&action=ban_content_writer&username=<?php echo $writer['username']; ?>">Ban</a></td>
            </tr>
        <?php endforeach; ?>
    </table>
<?php else: ?>
    <p>No content writers found.</p>
<?php endif; ?>

<a href="index.php?action=profile">Go to Profile</a>

</body>
</html>
