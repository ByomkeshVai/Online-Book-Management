<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" href="../style.css" />
   <meta http-equiv="Cache-control" content="no-cache">
</head>
<body>
    <h2>Welcome</h2>
    <p >Please login or register.</p>
    <p ><a href="index.php?action=login">Login</a> | <a href="index.php?action=register">Register</a></p>
    
</body>
</html>