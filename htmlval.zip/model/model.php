<?php

function connectToDatabase() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "htmlval";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
}



function getUserByToken($token) {
    $conn = connectToDatabase();
    $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = :token");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row;
}

function createUsersTable() {
    $conn = connectToDatabase();
    try {
        $sql = "CREATE TABLE IF NOT EXISTS users (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(30) NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(50),
            role VARCHAR(20),
            reset_token VARCHAR(255),  
            reset_token_expires DATETIME,
            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        $conn->exec($sql);
    } catch(PDOException $e) {
        echo "Error creating 'users' table: " . $e->getMessage();
    }
}


createUsersTable();

function register($username, $password, $email, $role) {
    $conn = connectToDatabase();

    $stmt = $conn->prepare("INSERT INTO users (username, password, email, role) VALUES (:username, :password, :email, :role)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':role', $role);
    $stmt->execute();
}

function getUserByUsername($username) {
    $conn = connectToDatabase();

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user;
}

function deleteUserByUsername($username) {
    $conn = connectToDatabase();

    try {
        $stmt = $conn->prepare("DELETE FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return true;
    } catch(PDOException $e) {
        echo "Error deleting user: " . $e->getMessage();
        return false;
    }
}

function updateUserByUsername($username, $newData) {
    $conn = connectToDatabase();

    try {
        $stmt = $conn->prepare("UPDATE users SET email = :email, role = :role WHERE username = :username");
        $stmt->bindParam(':email', $newData['email']);
        $stmt->bindParam(':role', $newData['role']);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return true;
    } catch(PDOException $e) {
        echo "Error updating user: " . $e->getMessage();
        return false;
    }
}

function getAllUsers() {
    $conn = connectToDatabase();

    try {
        $stmt = $conn->query("SELECT * FROM users");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error retrieving users: " . $e->getMessage();
        return false;
    }
}



function getUserByEmail($email) {
    $conn = connectToDatabase();
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row;
}

function updateUserResetToken($email, $token, $expires) {
    $conn = connectToDatabase();
    $stmt = $conn->prepare("UPDATE users SET reset_token = :token, reset_token_expires = :expires WHERE email = :email");
    $stmt->bindParam(':token', $token);
    $stmt->bindParam(':expires', $expires);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
}

function updateUserPassword($email, $newPassword) {
    $conn = connectToDatabase();
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_token_expires = NULL WHERE email = :email");
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
}

function createContentWritersTable() {
    $conn = connectToDatabase();
    try {
        $sql = "CREATE TABLE IF NOT EXISTS content_writers (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(30) NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(50),
            reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        $conn->exec($sql);
    } catch(PDOException $e) {
        echo "Error creating 'content_writers' table: " . $e->getMessage();
    }
}

createContentWritersTable();

function addContentWriter($username, $password, $email) {
    $conn = connectToDatabase();

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO content_writers (username, password, email) VALUES (:username, :password, :email)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        return "Content writer added successfully.";
    } catch(PDOException $e) {
        return "Error adding content writer: " . $e->getMessage();
    }
}

function banContentWriter($username) {
    if(empty($username)) {
        header("Location: index.php?action=manage_content_writers&message=Username is required.");
        exit;
    }

    $conn = connectToDatabase();

    try {
        // Find the content writer by username
        $stmt = $conn->prepare("SELECT id FROM content_writers WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $contentWriter = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$contentWriter) {
            header("Location: index.php?action=manage_content_writers&message=User not found.");
            exit;
        }

        $user_id = $contentWriter['id'];

      
        $stmt = $conn->prepare("DELETE FROM content_writers WHERE id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();


        $stmt = $conn->prepare("DELETE FROM users WHERE id = :user_id");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        header("Location: index.php?action=manage_content_writers&message=Content writer banned successfully.");
        exit;
    } catch(PDOException $e) {
        header("Location: index.php?action=manage_content_writers&message=Error banning content writer: " . $e->getMessage());
        exit;
    }
}

function getContentWriters() {
    $conn = connectToDatabase();

    try {
        $stmt = $conn->query("SELECT * FROM content_writers");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        echo "Error retrieving content writers: " . $e->getMessage();
        return false;
    }
}

function createReport($title, $content) {
    $conn = connectToDatabase();

    try {
        if (!isset($_COOKIE['username'])) {
            echo "User not logged in.";
            return false;
        }

        $username = $_COOKIE['username'];

        // Get the user ID of the content writer
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            echo "User not found.";
            return false;
        }

        $user_id = $user['id'];

        // Insert the report into reports table
        $stmt = $conn->prepare("INSERT INTO reports (user_id, title, content) VALUES (:user_id, :title, :content)");
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':content', $content);
        $stmt->execute();

        return true;
    } catch(PDOException $e) {
        echo "Error creating report: " . $e->getMessage();
        return false;
    }
}

?>